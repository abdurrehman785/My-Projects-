/*
Group Members :
Abdur Rehman (2023054)
Farheen Munir (2023199)
Mustafa Avais (2023564)
Ajwa Asghar (2023092)
Inshaal Sheeraz (2023260)
Section G (CE)
*/
#include<iostream>
#include <cstdlib>
#include<fstream>
#include<string>
#include<ctime>
#include<vector>
#include <cctype>
#include <sstream>
#include<conio.h>
using namespace std;
class User;
class Animal {
protected:
	string name;
	int happiness;
	int hygiene;
	string type;
	string family;
	char gender;
	vector<string>Inventory;
	time_t lastUpdate;
public:

	Animal(string n)   // parameterized constructor
	{
		name = n;
		happiness = 100;
		hygiene = 100;
		//lastUpdate = time(nullptr);
	}
	Animal() {
		name = "Pet1";
		happiness = 100;
		hygiene = 100;
		type = "Animal";
		family = "N/A";
		gender = '0';
	}
	void setType(string t) {
		type = t;
	}
	void display() {
		cout << "Name : " << name << endl;
		cout << "Family : " << family << endl;
		cout << "Type : " << type << endl;
		cout << "Gender : " << gender << endl;
		cout << "Hygiene : " << hygiene << endl;
		cout << "Happiness : " << happiness << endl;

	}
	vector<string> getInventory() {
		return Inventory;
	}
	void setInventory(vector<string>temp) {
		Inventory = temp;
	}

	friend void play(Animal* a, User* u);
	friend void VetAppointment(User& u);

	string getType() {
		return type;
	}
	//getter and setter functions 
	string getName() const { return name; }
	void setName(const string& n)
	{
		name = n;
	}

	int getHappiness() const
	{
		return happiness;
	}
	void setHappiness(int h)
	{
		happiness = h;
	}

	int getHygiene() const
	{
		return hygiene;
	}

	void setGender() {
		char g;
		bool isValid = false;

		do {
			cout << "Enter the gender of your pet (M/F): ";
			cin >> g;
			g = toupper(g); // Convert input to uppercase
			switch (g) {
			case 'M': {
				gender = 'M';
				isValid = true;
				break;
			}
			case 'F': {
				gender = 'F';
				isValid = true;
				break;
			}
			default: {
				cout << "Invalid choice entered. Please enter 'M' for male or 'F' for female.\n";
				isValid = false;
			}
			}
		} while (!isValid);
	}

	virtual void RandomCheck() {
		//This function randomly checks your pet
		srand(time(0));
		int temp = 1 + rand() % (1 + 3 - 1);
		switch (temp) {
		case 1: {
			cout << name << " is grumpy and will bite you\n";
			happiness -= 15;
		}
		case 2: {
			if (happiness >= 88 && happiness > 0) {
				cout << name << " is happy\n";
				break;
			}
			else {
				cout << name << " is just resting\n";
			}
		}
		case 3: {
			cout << name << " wants to cuddle\n" << endl;
		}
		}
	}
	string getGender() const
	{
		if (gender == 'M' || gender == 'm') {
			return "Male";
		}
		else {
			return "Female";
		}


	}
	friend void VisitMarket(User& u, Animal* a);
	void setfamily() {
		cin.ignore();
		// Define pet choices
		cout << "Enter the family of your pet : " << endl;   // write animals of your choice 
		getline(cin, family);// write animals of your choice 

	}
	void TempFamily(string t) {
		family = t;
	}
	string getfamily() const {
		return family;
	}

	void choosePet(int choice) {
		switch (choice) {
		case 1: {
			cout << "You chose a Dog.\n";
			break; }
		case 2: {
			cout << "You chose a Cat.\n";
			break; }
		case 3: {
			cout << "You chose a Bird.\n";
			break; }
		default: {
			cout << "Invalid choice. Please choose a number from 1 to 3.\n";
			break;
			}
		}
	}

	void setHygiene(int hy) { hygiene = hy; }
	void DisplayInventory() {
		cout << "Your inventory :\n";
		for (auto it = Inventory.begin(); it != Inventory.end(); ++it) {
			cout << *it << endl;
		}
	}
	virtual void groom() {
		hygiene += 23;
		happiness -= 23;
		cout << name << " is now clean.\n";

	};
	virtual void feed() {
		if (happiness < 100 && happiness > 0) {
			if (!Inventory.empty()) {
				happiness += 28;
				cout << getName() << " has been fed and is now active.....\n";
				Inventory.pop_back();
			}
			else {
				cout << "No items left in the inventory" << endl;
			}
		}
		else {
			cout << name << " does not want to be fed right now\n";
			happiness += 0;
		}
	}

	friend void play(Animal& a, User& u);


};

void Write(User, Animal*); // Prototype
class User {
private:
	string username;
	int currency;
	vector<string> friends;
public:
	User() {
		currency = 1500;
		username = "Abdul Qadeer Khan";
	}
	User(string n) {
		username = n;
		currency = 1500;
	}
	void SetName(string n) {
		username = n;
	}
	void SetCurrency(int c) {
		currency = c;
	}
	string getName() {
		return username;
	}
	int getCurrency() {
		return currency;
		// In the main body we shall use this function and subtract some amount when the user interacts with the pet
	}
	void Display() {
		cout << "Username : " << username << endl;
		cout << "Pet Bucks : " << getCurrency() << endl;

	}
	void AddFriend() {
		string usernames[] = { "BloodHound33","Minority199","Goated_AR","Baldwin092","AntiVenom260" };
		cin.ignore();
		cout << "Enter username to search : " << endl;
		string temp;
		getline(cin, temp);
		bool found = false;
		string user;
		int size = sizeof(usernames) / sizeof(usernames[0]);
		for (int i = 0; i < size; i++) {
			if (temp == usernames[i]) {
				cout << "User found...." << endl;
				user = usernames[i];
				found = true;
				break;
			}
		}
		if (found == true) {
			cout << "Enter Y to send a request to this user....\n";
			char temp;
			cin >> temp;
			if (temp == 'Y' || temp == 'y') {
				cout << "Request sent to " << user << endl;
				friends.push_back(user);
			}
		}
		else {
			cout << "User not found....." << endl;
		}
	}

	void Socialize() {
		int temp;
		cout << "Your friends are roaming around with their pets" << endl;
		do {
			cout << "1.Say Hi\n2.Request an item\n3.Play with their pet\n0.Exit\n";
			cin >> temp;
			if (temp == 0) {
				cout << "You walked away......" << endl;
			}
			else {
				switch (temp) {
				case 1: {
					srand(time(0));
					int t = 1 + rand() % (2 + 1 - 1);  // one of the 2 messages will be displayed randomly
					if (t == 1) {
						cout << getName() << " said Hi to another player and they responded back....." << endl;
					}
					if (t == 2) {
						cout << getName() << " said Hi to another player and they ignored......" << endl;
					}
					break;
				}
				case 2: {
					cout << "1.Food item 15$ \n2.Accessory 20$\n3.Health Item 17$\n0.Exit\n";
					int t;
					cin >> t;
					if (t == 1) {
						cout << getName() << " requested a Food item from another player and they responded back....." << endl;
						currency -= 15;
					}
					if (t == 2) {
						cout << getName() << " requested an accessory from another player and they responded back......" << endl;

						currency -= 20;
					}
					if (t == 3) {
						cout << getName() << " requested a health item from another player and they responded back......" << endl;

						currency -= 17;
					}
					if (t == 0) {
						cout << "No items reqesuted.....\n";

					}
					else {
						cout << "Invalid choice entered\n";
					}
					break;
				}
				case 3:
				{
					cout << getName() << " played with another user's pet....." << endl;
					break;
				}
				case 0: {
					break;
				}
				default: {
					cout << "Invalid choice entered.....\n";
				}
				}
			}
		} while (temp != 0);
	}
	/*void LogOut(string filename, User u, Animal* a) {
		cout << "Are you sure you want to logout ? (Y for Yes and N for No)\n";
		char temp;
		cin >> temp;
		switch (temp) {
		case 'Y': {
			cout << "Logging out.....\n";
			Write(filename, u, a);
			cout << "Data saved.....\nLogged out successfully\n";
			break;
		}
		case 'y': {
			cout << "Logging out.....\n";
			Write(filename, u, a);
			cout << "Data saved.....\nLogged out successfully\n";
			break;
		}
		case 'n': {
			cout << "Back to your pets\n";
			break;
		}
		case 'N': {
			cout << "Back to your pets\n";
			break;
		}
		default: {
			cout << "Invalid choice entered....." << endl;
		}
		}
	}*/
}; 
void Write(User u, Animal* a) {
	ofstream f;
	f.open(u.getName(), ios::trunc);
	f << u.getName() << endl;
	f << u.getCurrency() << endl;
	f << a->getName() << endl;
	f << a->getHappiness() << endl;
	f << a->getHygiene() << endl;
	f << a->getfamily() << endl;
	f << a->getGender() << endl;
	f << a->getType() << endl;
	f.close();
}


class Cat : public Animal {
public:
	// Default Constructor
	Cat() : Animal() {
		type = "Cat";

	}

	// parameterized constructor	
	Cat(string n) : Animal(n) {
		type = "Cat";
		setfamily();
		setGender();
	}
	friend void VisitMarket(User& u, Animal* a);
	friend void play(Animal& a, User& u);
	void display() {
		cout << "Name : " << name << endl;
		cout << "Family : " << family << endl;
		cout << "Gender : " << gender << endl;
		cout << "Hygiene : " << hygiene << endl;
		cout << "Happiness : " << happiness << endl;
		cout << "Type : " << type << endl;
	}
	void RandomCheck() {
		
		srand(time(0));
		int temp = 1 + rand() % (1 + 3 - 1);
		switch (temp) {
		case 1: {
			cout << name << " is grumpy and will bite you\n";
			happiness -= 15;
			break;
		}
		case 2: {
			if (happiness >= 88 && happiness > 0) {
				cout << name << " is happy\n";
				break;
			}
			else {
				cout << name << " is just lying down\n";
				break;
			}
		}
		case 3: {
			cout << name << " wants to cuddle\n" << endl;
			break;
		}
		}
	}
	void groom() {
		int choice;
		do {
			cout << "Grooming " << name << endl;
			cout << "What would you like to do?\n";
			cout << "1. Cut Nails (+3 Hygiene)\n";
			cout << "2. Trim Fur (+5 Hygiene)\n";
			cout << "3. Shower (+10 Hygiene)\n";
			cout << "4. Check for Lice (+5 Hygiene)\n";
			cout << "5. Exit\n";
			cin >> choice;
			if (choice == 5) {
				cout << "Grooming session ended......." << endl;
			}
			else {
				switch (choice) {
				case 1:
					hygiene += 3;
					cout << "Nails have been cut for " << name << "." << endl;
					break;
				case 2:
					hygiene += 5;
					cout << "Fur has been trimmed for " << name << "." << endl;
					break;
				case 3:
					hygiene += 10;
					cout << "You have showered " << name << "." << endl;
					break;
				case 4:
					hygiene += 5;
					cout << "You have checked " << name << " for lice." << endl;
					break;
				case 5:
					cout << "Exiting grooming session." << endl;
					break;
				default:
					cout << "Invalid choice. Please try again." << endl;
				}
			}
		} while (choice != 5);
		happiness -= 15;
		cout << name << "'s happiness decreased slightly due to grooming." << endl;
	}

	void feed() {
		if (happiness < 80 && happiness > 0) {
			if (!Inventory.empty()) {
				happiness += 18;
				cout << getName() << " has been fed and is now active.....\n";
				Inventory.pop_back();
			}
			else {
				cout << "No items left in the inventory" << endl;
			}
		}
		else {
			cout << name << " was fed too much and it threw up\n";
			hygiene -= 20;
		}

	}

};

class Dog : public Animal {
public:
	// Default Constructor
	Dog() : Animal() {
		type = "Dog";
	}
	// parameterized constructor
	Dog(string n) : Animal(n) {
		type = "Dog";
		setfamily();
		setGender();
	}
	void RandomCheck() {
		//This function randomly checks your pet
		srand(time(0));
		int temp = 1 + rand() % (1 + 3 - 1);
		switch (temp) {
		case 1: {
			cout << name << " is grumpy and will bite you\n";
			happiness -= 15;
			break;
		}
		case 2: {
			if (happiness >= 88 && happiness > 0) {
				cout << name << " is happy\n";
				break;
			}
			else {
				cout << name << " is just lying down\n";
				break;
			}
		}
		case 3: {
			cout << name << " wants to cuddle\n" << endl;
			break;
		}
		}
	}
	friend void VisitMarket(User& u, Animal* a);
	void display() {
		cout << "Name : " << name << endl;
		cout << "Family : " << family << endl;
		cout << "Gender : " << gender << endl;
		cout << "Hygiene : " << hygiene << endl;
		cout << "Happiness : " << happiness << endl;
		cout << "Type : " << type << endl;
	}
	friend void play(Animal& a, User& u);
	void groom() {
		int choice;
		do {
			cout << "Grooming " << name << endl;
			cout << "What would you like to do?\n";
			cout << "1. Cut Nails (+3 Hygiene)\n";
			cout << "2. Trim Fur (+5 Hygiene)\n";
			cout << "3. Shower (+10 Hygiene)\n";
			cout << "4. Check for Lice (+5 Hygiene)\n";
			cout << "5. Exit\n";
			cin >> choice;
			if (choice == 5) {
				cout << "Grooming session ended....." << endl;
			}
			else {
				switch (choice) {
				case 1:
					hygiene += 3;
					cout << "Nails have been cut for " << name << "." << endl;
					break;
				case 2:
					hygiene += 5;
					cout << "Fur has been trimmed for " << name << "." << endl;
					break;
				case 3:
					hygiene += 10;
					cout << "You have showered " << name << "." << endl;
					break;
				case 4:
					hygiene += 5;
					cout << "You have checked " << name << " for lice." << endl;
					break;
				case 5:
					cout << "Exiting grooming session." << endl;
					break;
				default:
					cout << "Invalid choice. Please try again." << endl;
				}
			}
		} while (choice != 5);
		happiness -= 15;
		cout << name << "'s happiness decreased slightly due to grooming." << endl;
	}

	void feed() {
		if (happiness < 80 && happiness > 0) {
			if (!Inventory.empty()) {
				happiness += 28;
				cout << getName() << " has been fed and is now active.....\n";
				Inventory.pop_back();
			}
			else {
				cout << "No items left in the inventory" << endl;
			}
		}
		else {
			cout << name << " was fed too much and it threw up\n";
			hygiene -= 20;
		}

	}

};


class Bird : public Animal {
public:

	Bird() : Animal() {
		type = "Bird";
	}

	// parameterized constructor
	Bird(string n) : Animal(n) {
		type = "Bird";
		setGender();
		setfamily();
	}
	void RandomCheck() {

		srand(time(0));
		int temp = 1 + rand() % (1 + 3 - 1);
		switch (temp) {
		case 1: {
			cout << name << " is grumpy and will bite you\n";
			happiness -= 15;
			break;
		}
		case 2: {
			if (happiness >= 88 && happiness > 0) {
				cout << name << " is happy\n";
				break;
			}
			else {
				cout << name << " is just lying down\n";
				break;
			}
		}
		case 3: {
			cout << name << " wants to cuddle\n" << endl;
			break;
		}
		}
	}
	friend void VisitMarket(User& u, Animal* a);

	void display() {
		cout << "Name : " << name << endl;
		cout << "Family : " << family << endl;
		cout << "Gender : " << gender << endl;
		cout << "Hygiene : " << hygiene << endl;
		cout << "Happiness : " << happiness << endl;
		cout << "Type : " << type << endl;
	}
	friend void play(Animal* a, User& u);

	void groom() {
		int choice;
		do {
			cout << "Grooming " << name << endl;
			cout << "What would you like to do?\n";
			cout << "1. Cut Nails (+3 Hygiene)\n";
			cout << "2. Trim Fur (+5 Hygiene)\n";
			cout << "3. Shower (+10 Hygiene)\n";
			cout << "4. Check for Lice (+5 Hygiene)\n";
			cout << "5. Exit\n";
			cin >> choice;
			if (choice == 5) {
				cout << "Grooming session ended....." << endl;
			}
			else {
				switch (choice) {
				case 1:
					hygiene += 3;
					cout << "Nails have been cut for " << name << "." << endl;
					break;
				case 2:
					hygiene += 5;
					cout << "Fur has been trimmed for " << name << "." << endl;
					break;
				case 3:
					hygiene += 10;
					cout << "You have showered " << name << "." << endl;
					break;
				case 4:
					hygiene += 5;
					cout << "You have checked " << name << " for lice." << endl;
					break;
				case 5:
					cout << "Exiting grooming session." << endl;
					break;
				default:
					cout << "Invalid choice. Please try again." << endl;
				}
			}
		} while (choice != 5);
		happiness -= 15;
		cout << name << "'s happiness decreased slightly due to grooming." << endl;
	}

	void feed() {
		if (happiness < 85 && happiness > 0) {
			if (!Inventory.empty()) {
				happiness += 28;
				cout << getName() << " has been fed and is now active.....\n";
				Inventory.pop_back();
			}
			else {
				cout << "No items left in the inventory" << endl;
			}
		}
		else {
			cout << name << " was fed too much and it threw up\n";
			hygiene -= 20;
		}

	}
};

void play(Animal* a, User& u) {
	if (a->getHappiness() > 0) {
		if (a->getType() == "Cat") {
			srand(time(0));
			int temp = 1 + rand() % (1 + 2 - 1);
			switch (temp) {
			case 1: {
				cout << a->getName() << " played and dug around and found a cotton yarn, a ball, and a bubble wrap to scratch\n";
				a->setHappiness(a->getHappiness() + 23);
				int temp_c = u.getCurrency() + 700;
				a->setHygiene(a->getHygiene() - 20);
				u.SetCurrency(temp_c);
				break;
			}
			case 2: {
				cout << a->getName() << " played and dug around but found nothing of its interest\n";
				a->setHappiness(a->getHappiness() + 15);
				int temp_c = u.getCurrency() + 350;
				a->setHygiene(a->getHygiene() - 14);
				u.SetCurrency(temp_c);
				break;
			}
			default: {
				cout << a->getName() << " didn't find anything interesting to play with\n";
				break;
			}
			}
		}
		if (a->getType() == "Dog") {
			srand(time(0));
			int temp = 1 + rand() % (1 + 2 - 1);
			switch (temp) {
			case 1: {
				cout << a->getName() << " played and dug around and found a stick , a ball, and a shoe to chew on\n";
				a->setHappiness(a->getHappiness() + 23);
				int temp_c = u.getCurrency() + 700;
				a->setHygiene(a->getHygiene() - 20);
				u.SetCurrency(temp_c);
				break;
			}
			case 2: {
				cout << a->getName() << " played and dug around but found nothing of its interest\n";
				a->setHappiness(a->getHappiness() + 15);
				int temp_c = u.getCurrency() + 350;
				a->setHygiene(a->getHygiene() - 14);
				u.SetCurrency(temp_c);
				break;
			}
			default: {
				cout << a->getName() << " didn't find anything interesting to play with\n";
				break;
			}
			}
		}
		
		if (a->getType() == "Bird") {
			srand(time(0));
			int temp = 1 + rand() % (1 + 2 - 1);
			switch (temp) {
			case 1: {
				cout << a->getName() << " sang and flew around to attack someone\n";
				a->setHappiness(a->getHappiness() + 23);
				int temp_c = u.getCurrency() + 700;
				a->setHygiene(a->getHygiene() - 20);
				u.SetCurrency(temp_c);
				break;
			}
			case 2: {
				cout << a->getName() << " did not find a bird to attack\n";
				a->setHappiness(a->getHappiness() + 15);
				int temp_c = u.getCurrency() + 350;
				a->setHygiene(a->getHygiene() - 14);
				u.SetCurrency(temp_c);
				break;
			}
			default: {
				cout << a->getName() << " didn't find anything interesting to play with\n";
				break;
			}
			}
		}
	}
	
}

void VetAppointment(User& u, Animal* a) {
	int choice;
	cout << "Appointment for your pet\n";
	do {
		cout << "Welcome to the Royal Pets hospital. Please select a service:" << endl;
		cout << "1. Pet Vaccination ($50):" << endl;
		cout << "2. Dental Checkup ($30):" << endl;
		cout << "3. Nutritional and Diet Consultation ($40):" << endl;
		cout << "4. Behavioral Consultations ($60):" << endl;
		cout << "5. Other Diagnostic Procedures ($70):" << endl;
		cout << "0. Exit" << endl;
		cout << "Enter your choice:";
		cin >> choice;
		if (choice == 0) {
			cout << "You left the vet clinic\n";
			break;
		}
		else {
			switch (choice) {
			case 1: {
				cout << "Your pet has been vaccinated:" << endl;
				int temp = u.getCurrency() - 50;
				a->setHappiness(a->getHappiness() - 15);
				u.SetCurrency(temp);

				break;
			}
			case 2: {
				cout << "Your pet has had a dental checkup:" << endl;
				a->setHappiness(a->getHappiness() - 12);
				int temp = u.getCurrency() - 30;
				u.SetCurrency(temp);
				break;
			}
			case 3: {
				cout << "Your pet has received a nutritional and diet consultation:" << endl;
				int temp = u.getCurrency() - 40;
				u.SetCurrency(temp);
				break;
			}
			case 4: {
				cout << "Your pet has had a behavioral consultation:" << endl;
				int temp = u.getCurrency() - 60;
				u.SetCurrency(temp);
				break;
			}
			case 5: {
				cout << "Your pet has undergone other diagnostic procedures:" << endl;
				a->setHappiness(a->getHappiness() - 15);
				int temp = u.getCurrency() - 70;
				u.SetCurrency(temp);
				break;
			}
			case 0:
				break;
			default:
				cout << "Invalid choice:" << endl;
			}
		}
	} while (choice != 0);
}
void VisitMarket(User& u, Animal* a)
{
	vector<string>temp = a->getInventory();
	cout << "Welcome to the market" << endl;
	int t;
	cout << "Note : Only buy items that will last for the current session else they will rot\n";

	do {
		cout << "What would you like to buy for your pets ? " << endl;
		cout << "1.Fruits 10$ \n2.Pet Food 20$ \n3.Milk 6$ \n4.Vitamins 15$\n5.Candies 9$\n6.Oatmeal 11$\n0.Exit\n" << endl;

		cin >> t;
		if (t == 0) {
			break;
			cout << "You left the market...\n";
		}
		else {
			switch (t) {
			case 1: {
				temp.push_back("Fruits");
				u.SetCurrency(u.getCurrency() - 10);
				cout << "Item purchased.....\n";
				break;
			}
			case 2: {
				temp.push_back("Pet Food");
				u.SetCurrency(u.getCurrency() - 20);
				cout << "Item purchased.....\n";
				break;
			}
			case 3: {
				temp.push_back("Milk");
				u.SetCurrency(u.getCurrency() - 6);
				cout << "Item purchased.....\n";
				break;
			}
			case 4: {
				temp.push_back("Vitamins");
				u.SetCurrency(u.getCurrency() - 20);
				cout << "Item purchased.....\n";
				break;
			}
			case 5: {
				temp.push_back("Candies");
				u.SetCurrency(u.getCurrency() - 9);
				cout << "Item purchased.....\n";
				break;
			}
			case 6: {
				temp.push_back("Oatmeal");
				u.SetCurrency(u.getCurrency() - 11);
				cout << "Item purchased.....\n";
				break;
			}
			case 0:
				break;
			default:
				cout << "Invalid choice entered....." << endl;
			}
		}

	} while (t != 0);
	a->setInventory(temp);
}
void generateRandomContent() {
	vector<string> allTips = {

		"Did you know that cats have a strong sense of smell, hearing, and vision?",
		"Cats are obligate carnivores, meaning they need meat in their diet to survive.",
		"Provide your cat with plenty of scratching posts to keep their claws healthy and to prevent them from scratching furniture.",
		"Cats enjoy elevated spaces, so provide them with cat trees or shelves to climb.",
		"Ensure your cat has access to clean, fresh water at all times.",
		"Regularly brush your cat's fur to prevent matting and reduce shedding.",
		"Keep toxic plants, foods, and household items out of your cat's reach.",
		"Dogs are social animals and thrive on companionship. Spend quality time with your dog every day.",
		"Regular exercise is important for dogs to maintain physical and mental health.",
		"Positive reinforcement training techniques work best for teaching dogs new behaviors.",
		"Properly socialize your dog from a young age to prevent behavior problems later in life.",
		"Provide your dog with regular veterinary care, including vaccinations and parasite prevention.",
		"Avoid leaving your dog alone for long periods. Enrich their environment with toys and puzzles.",
		"Teach your dog basic commands like sit, stay, and come for better control and safety.",
		"Birds have a high metabolic rate and need a balanced diet that includes seeds, fruits, vegetables, and protein sources like insects.",
		"Provide your bird with plenty of toys and mental stimulation to prevent boredom and feather picking.",
		"Regularly clean your bird's cage and provide fresh water daily to maintain hygiene.",
		"Avoid placing your bird's cage in drafty or overly sunny areas of your home.",
		"Allow your bird plenty of out-of-cage time for exercise and socialization.",
		"Cover your bird's cage at night to ensure they get enough rest.",
		"Avoid using non-stick cookware around birds, as the fumes can be toxic to them.",
		"Provide your bird with a variety of perches with different textures and diameters to maintain foot health."
	};
	srand(time(0));
	// Generate a random index
	int index = rand() % allTips.size();

	// Output the random tip
	cout << "Tip : " << allTips[index] << endl;
}
void CheckStats(Animal* a) {
	if (a->getHappiness() < 0) {
		a->setHappiness(0);
	}
	if (a->getHappiness() > 100) {
		a->setHappiness(100);
	}
	if (a->getHappiness() < 30) {
		cout << a->getName() << " is extremely unhappy\n";
	}
	if (a->getHygiene() < 0) {
		a->setHygiene(0);
	}
	if (a->getHygiene() > 100) {
		a->setHygiene(100);
	}
	if (a->getHappiness() < 30) {
		cout << a->getName() << " is dirty\n";
	}
}
struct TempData { // This struct is for the Read Function.
	string user_name;
	int currency;
	string pet_name;
	int happiness;
	int hygiene;
	string pet_family;
	string pet_gender;
	string type;
};
void Read(User& u, Animal*& a) {
	ifstream file(u.getName());
	if (file.is_open()) {
		TempData data;
		while (file >> data.user_name >> data.currency >> data.pet_name >> data.happiness >> data.hygiene >> data.pet_family >> data.pet_gender >> data.type) {
			u.SetName(data.user_name);
			u.SetCurrency(data.currency);
			if (data.type == "Cat") {
				delete a; // Delete old animal object if it exists
				a = new Cat(data.pet_name);
				break;
			}
			if (data.type == "Dog") {
				delete a;
				a = new Dog(data.pet_name);
				break;
			}
			if (data.type == "Bird") {
				delete a;
				a = new Bird(data.pet_name);
				break;
			}

			if (a) {
				a->setHappiness(data.happiness);
				a->setHygiene(data.hygiene);
				a->TempFamily(data.pet_family);
				a->setType(data.type);
			}
		}
		file.close();
	}
}
int main() {
	// User and Pet Initialization
	User user;
	string f;
	string userName;
	Animal* pet = nullptr; // Pointer to an Animal object (can hold Cat, Dog, Bird)
	cout << "Welcome to the Pet Simulator!" << endl;
	cout << "Enter your username: ";
	getline(cin, userName);
	user.SetName(userName);

	// Check if save file exists and offer to load data
	ifstream saveFile(userName);
	if (saveFile.is_open()) {
		cout << "Save file found. Load data? (y/n): ";
		char choice;
		cin >> choice;
		if (tolower(choice) == 'y') {
			Read(user, pet);
		}
		else {
			cout << "Starting a new game." << endl;
			// Create a new pet (Cat, Dog, or Bird) based on user choice
			int petChoice;
			cout << "Choose your pet type (1 - Cat, 2 - Dog, 3 - Bird): ";
			cin >> petChoice;
			switch (petChoice) {
			case 1:
				pet = new Cat(); // Replace with new Cat object creation.
				pet->setfamily();
				pet->setGender();
				break;
			case 2:
				pet = new Dog(); // Replace with new Dog object creation
				pet->setfamily();
				pet->setGender();

				break;
			case 3:
				pet = new Bird(); // Replace with new Bird object creation
				pet->setfamily();
				pet->setGender();

				break;
			default:
				cout << "Invalid choice. Defaulting to Cat." << endl;
				pet = new Cat(); // Replace with new Cat object creation
				pet->setfamily();
				pet->setGender();

			}
			// Set initial name for the pet (optional)
			string petName;
			cin.ignore();
			cout << "Enter a name for your pet: ";
			getline(cin, petName);
			pet->setName(petName);


		}
	}
	else {
		cout << "No save file found. Starting a new game." << endl;
		// Create a new pet (Cat, Dog, or Bird) based on user choice (same as above)
		// Set initial name for the pet (optional)
		int petChoice;
		cout << "Choose your pet type (1 - Cat, 2 - Dog, 3 - Bird): ";
		cin >> petChoice;
		switch (petChoice) {
		case 1:
			pet = new Cat();
			pet->setfamily();
			pet->setGender();
			// Replace with new Cat object creation
			break;
		case 2:
			pet = new Dog();
			pet->setfamily();
			pet->setGender();
			// Replace with new Dog object creation
			break;
		case 3:
			pet = new Bird();
			pet->setfamily();
			pet->setGender();
			// Replace with new Bird object creation
			break;
		default:
			cout << "Invalid choice. Defaulting to Cat." << endl;
			pet = new Cat();
			pet->setfamily();
			pet->setGender();
			// Replace with new Cat object creation
		}
		// Set initial name for the pet (optional)
		string petName;
		cout << "Enter a name for your pet: ";
		cin >> petName;
		pet->setName(petName);
		cout << "Your pet's name is: " << petName << endl;

	}
	system("PAUSE");
	// Main Game Loop
	int choice;
	do {
		cout << "\n\t\t\t" << __TIMESTAMP__ << endl;
		cout << "\nWhat would you like to do?" << endl;
		cout << "1. Play with your pet" << endl;
		cout << "2. Feed your pet" << endl;
		cout << "3. Groom your pet" << endl;
		cout << "4. Take your pet to the vet" << endl;
		cout << "5. Visit the Marketplace" << endl;
		cout << "6. View pet stats" << endl;
		cout << "7. Get a random pet care tip" << endl;
		cout << "8. Save game and exit" << endl;
		cout << "9. Take your pet to the park and socialize with other users\n";
		cout << "10. Add Friends\n";
		cout << "11. View " << user.getName() << "'s stats\n";
		cout << "12. View Inventory\n";
		cout << "13. See what your pet is up to\n";
		cout << "0. Exit without saving" << endl;
		cout << "Enter your choice: ";
		cin >> choice;

		switch (choice) {
		case 1:
		{
			play(pet, user);
			CheckStats(pet);
			system("PAUSE");
			// Call the play function with the current pet and user object
			break;
		}
		case 2:
		{
			pet->feed();
			CheckStats(pet);
			system("PAUSE");
			break;
		}
		case 3:
		{
			pet->groom();
			CheckStats(pet);
			system("PAUSE");
			break;
		}
		case 4:
		{
			VetAppointment(user, pet);
			CheckStats(pet);
			CheckStats(pet);
			system("PAUSE");
			break;
		}
		case 5:
		{
			VisitMarket(user, pet);
			system("PAUSE");
			break;
		}

		case 6:
			pet->display();
			CheckStats(pet);
			system("PAUSE");
			break;
		case 7:
			generateRandomContent();
			system("PAUSE");
			break;
		case 8:
		{
			// Save game data to a file (implement using user and pet attributes)
			cout << "Saving game..." << endl;
			Write(user, pet);
			break;
		}
		case 9: {
			user.Socialize();
			system("PAUSE");
			break;
		}
		case 10: {
			user.AddFriend();
			system("PAUSE");
			break;
		}
		case 11: {
			user.Display();
			system("PAUSE");
			break;
		}
		case 12: {
			pet->DisplayInventory();
			system("PAUSE");
			break;
		}
		case 13: {
			pet->RandomCheck();
			CheckStats(pet);
			system("PAUSE");
			break;
		}
		case 0:
			cout << "Exiting the game..." << endl;
			break;
		default:
			cout << "Invalid choice. Please try again." << endl;
		}

		// Update pet stats after each action (call updateStats function from Animal)
	system("cls");
	} while ((choice != 0) && (choice != 8));

	// Delete the dynamically allocated pet object to prevent memory leaks
	delete pet;
	return 0;
}